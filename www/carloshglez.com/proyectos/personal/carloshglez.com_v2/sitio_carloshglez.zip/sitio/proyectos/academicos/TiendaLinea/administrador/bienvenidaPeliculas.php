 <?php 
 		include("header.html");
 ?>
 <td bgcolor="#FFFFFF" width="750">
   <h1> Bienvenido </h1>
   <p align="justify">Somos una empresa dedicada a la venta de peliculas, establecida en Córdoba-Veracruz.
   Somos los primeros en traer a ti la película que esperabas ver con ansiedad desde la comodida de tu hogar.</p>
  
</td>
</tr>
  
<?php 
 		include("footer.html");
 ?>
 