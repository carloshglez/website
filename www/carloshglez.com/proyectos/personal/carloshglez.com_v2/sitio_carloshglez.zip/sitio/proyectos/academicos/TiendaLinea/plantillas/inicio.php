<?php
	include("header.html");
?>

<table width="800" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><h5 style="color: #000F5C">Inicio - &iexcl;&iexcl; Bienvenido !! </h5></td>
  </tr>
  <tr>
    <td><table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td colspan="2"><h1>Mensaje de Bienvenida:</h1>
          <p align="justify">Ciegos Fundaci&oacute;n Roma A.C es un activo particip&aacute;nte en la rehabilitaci&oacute;n y capacitaci&oacute;n de adultos y ni&ntilde;os con una deficiencia visual. Nos encargamos del crecimiento y desarrollo de nuestros alumnos para que se puedan incorporar a la sociedad donde puedan realizar alg&uacute;n oficio y ser autosuficientes.</p>
          <p align="justify">Actualmente nuestra meta est&aacute; en la construcci&oacute;n de la escuela donde, a pesar de estar incompleta, nuestros alumnos diariamante realizan sus actividades y logran su aprendizaje </p>
          <br>
          </td>
        <td width="257"><div align="center"><img src="imagenes/imageninicio.jpg" width="160" height="146"></div></td>
      </tr>
      <tr>
        <td colspan="3">&nbsp;</td>
        </tr>
      <tr>
        <td width="256"><div align="center">
          <h4>Conoce nuestras 
            <br>
            actividades </h4>
          </div></td>
        <td width="257"><h4 align="center">Ayudanos haciendo un Donativo</h4>
          </td>
        <td><div align="center">
          <h4>Visita la escuela</h4>
        </div></td>
      </tr>
      <tr>
        <td><div align="center"><img src="imagenes/eventos.jpg" width="222" height="133"></div></td>
        <td><div align="center"><img src="imagenes/nino2.jpg" width="200" height="133"></div></td>
        <td><div align="center"><img src="imagenes/imageninicio2.jpg" width="200" height="133"></div></td>
      </tr>
      <tr>
        <td><div align="center"><a href="actividades.php" class="mylink5">Ver las actividades</a></div></td>
        <td><div align="center"><a href="donativos.php" class="mylink5">Informes Aqui </a></div></td>
        <td><div align="center"><a href="contactanos.php" class="mylink5">Contacto</a></div></td>
      </tr>
    </table></td>
  </tr>
</table>

<?php
	include("footer.html");
?>