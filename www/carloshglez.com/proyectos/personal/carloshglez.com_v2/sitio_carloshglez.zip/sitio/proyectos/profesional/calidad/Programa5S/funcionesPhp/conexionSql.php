<?php

function Conectar()
{
	if(!($Conecta=mysql_connect("mysql.nixiweb.com","u506695579_5s","carlos"))){
		print("Error en la conexion al servidor de la base de datos");	
		exit();
	}
	if(!(mysql_select_db("u506695579_5s", $Conecta))){
		print("No se encontro la base de datos");	
		exit();
	}
	return $Conecta;
}

function Desconectar($Conexion)
{
	mysql_close($Conexion);
}

?>