	//FUNCIONES DEL SUBMENU////////////////////////////////////////////////////////////////////////////////
	function big() {
		document.getElementById("Layer1").style.height='250px';
	}

	function small() {
		document.getElementById("Layer1").style.height='70px';
	}

	function start() {
		document.all.Layer1.style.height='70px';
	}
	/////////////////////////////////////////////////////////