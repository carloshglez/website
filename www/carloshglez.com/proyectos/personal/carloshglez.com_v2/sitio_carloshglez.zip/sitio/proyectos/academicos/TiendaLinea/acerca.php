<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<table width="750" border="0" align="center" cellpadding="0" cellspacing="0" id="intro">
  <tr>
    <td class="migas">Inicio &gt; Acerca de</td>
  </tr>
  <tr>
    <td><h2>Acerca de</h2></td>
  </tr>
  <tr>
    <td><p><strong>Proyecto Final:</strong> <em>Tienda de Peliculas</em><br />
      </p>
      <hr />
      <p><strong>Nombre de la materia:</strong> Desarrollo de Aplicaciones Distribuidas<br />
      </p>
      <p><strong>Integrantes:</strong><br />
        José Rogelio Rodríguez Rodríguez<br />
        Carlos Horacio González Gordillo<br />
    </p></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>