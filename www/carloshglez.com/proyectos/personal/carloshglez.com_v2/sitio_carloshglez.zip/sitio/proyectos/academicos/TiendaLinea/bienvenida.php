<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sin título</title>
</head>

<body>
<table width="750" border="0" align="center" cellpadding="0" cellspacing="0" id="intro">
  <tr>
    <td class="migas">Inicio</td>
  </tr>
  <tr>
    <td><h2>Bienvenida</h2></td>
  </tr>
  <tr>
    <td><table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="500"><p align="justify">En este sitio encontrarás una extensa variedad de peliculas para que disfrutes con tu familia y amigos. Somos una empresa dedicada a la venta de peliculas, establecida en Córdoba siendo los primeros en traer a ti la película que esperabas ver con ansiedad desde la comodida de tu hogar.</p></td>
          <td width="200" align="center"><img src="imagenes/cine1.jpg" width="150" height="150" alt="Peliculas" /></td>
        </tr>
      </table>
<br />
    <table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="200" align="center"><img src="imagenes/movieTape.jpg" width="150" height="100" alt="Peliculas" /></td>
        <td width="500"><p align="justify">Contamos con una colección de peliculas organizadas por nombre, genero o clasificación para que la experiencia de buscar las peliculas sea más confortable. También podrás consultar la lista de peliculas que tenemos a tu disposición. Y estamos en constante actualización para poner a tu alcance las peliculas más recientes.<br />
        </p></td>
      </tr>
    </table>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>